﻿namespace session1.Models
{
    public class User
    {
        public int UId { get; set; }
        public string UserName { get; set; }
        public int UserAge { get; set; }
        public string Email { get; set; }
    }
}
