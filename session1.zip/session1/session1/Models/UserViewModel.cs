﻿namespace session1.Models
{
    public class UserViewModel
    {
        public string UserName { get; set; }
        public int UserAge { get; set; }
        public string Email { get; set; }
    }
}
