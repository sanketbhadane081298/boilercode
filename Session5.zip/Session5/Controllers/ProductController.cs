﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Session5.DBModels;

namespace Session5.Controllers
{
    [Authorize]
    [ApiController]
    public class ProductController : ControllerBase
    {
        ProductDBContext _context = new ProductDBContext();


        [HttpGet]
        [Route("GetAllProducts")]
        public async Task<IActionResult> GetAllProducts()
        {
            return Ok(_context.Products.ToList());
        }

        [HttpGet]
        [Route("GetProductByCode")]
        public async Task<IActionResult> GetProductByCode(string ProductCode)
        {
            return Ok(_context.Products.Where(e => e.ProductCode == ProductCode).FirstOrDefault());
        }
    }
}
