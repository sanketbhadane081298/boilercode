﻿namespace Session5.DBModels
{
    public class Product
    {
        public decimal Id { get; set; }

        public string? ProductCode { get; set; }

        public string? ProductName { get; set; }

        public decimal? Categoryid { get; set; }

        public double? Price { get; set; }

        public double? StkQty { get; set; }

        public decimal? VendorId { get; set; }

        public virtual Category? Category { get; set; }

        public virtual Vendor? Vendor { get; set; }
    }
}
