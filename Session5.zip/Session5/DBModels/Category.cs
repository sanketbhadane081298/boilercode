﻿namespace Session5.DBModels
{
    public class Category
    {
        public decimal Id { get; set; }

        public string? CategoryName { get; set; }

        public virtual ICollection<Product> Products { get; } = new List<Product>();
    }
}
