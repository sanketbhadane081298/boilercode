﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
namespace Session5.DBModels
{
    public class ProductDBContext : DbContext
    {
        public ProductDBContext()
        {
        }

        public ProductDBContext(DbContextOptions<ProductDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Category> Categories { get; set; }

        public virtual DbSet<Product> Products { get; set; }

        public virtual DbSet<User> Users { get; set; }

        public virtual DbSet<Vendor> Vendors { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
            => optionsBuilder.UseSqlServer("Data Source=LAPTOP-P6DCIL3L;Initial Catalog=ProductData;uid=sa;password=sql;TrustServerCertificate=True");

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>(entity =>
            {
                entity.ToTable("Tbl_Category");

                entity.Property(e => e.Id)
                    .ValueGeneratedOnAdd()
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("ID");
                entity.Property(e => e.CategoryName).HasMaxLength(50);
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("Tbl_Product");

                entity.Property(e => e.Id)
                    .ValueGeneratedOnAdd()
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("ID");
                entity.Property(e => e.Categoryid).HasColumnType("numeric(18, 0)");
                entity.Property(e => e.ProductCode).HasMaxLength(50);
                entity.Property(e => e.ProductName).HasMaxLength(100);
                entity.Property(e => e.VendorId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("VendorID");

                entity.HasOne(d => d.Category).WithMany(p => p.Products)
                    .HasForeignKey(d => d.Categoryid)
                    .HasConstraintName("FK_Tbl_Product_Tbl_Category");

                entity.HasOne(d => d.Vendor).WithMany(p => p.Products)
                    .HasForeignKey(d => d.VendorId)
                    .HasConstraintName("FK_Tbl_Product_Tbl_Vendor");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.EmailId);

                entity.ToTable("Tbl_User");

                entity.Property(e => e.EmailId).HasMaxLength(50);
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");
                entity.Property(e => e.Designation).HasMaxLength(50);
                entity.Property(e => e.FullName).HasMaxLength(50);
                entity.Property(e => e.Id)
                    .ValueGeneratedOnAdd()
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("ID");
                entity.Property(e => e.Password).HasMaxLength(50);
            });

            modelBuilder.Entity<Vendor>(entity =>
            {
                entity.ToTable("Tbl_Vendor");

                entity.Property(e => e.Id)
                    .ValueGeneratedOnAdd()
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("ID");
                entity.Property(e => e.VendorCode).HasMaxLength(50);
                entity.Property(e => e.VendorEmail).HasMaxLength(100);
                entity.Property(e => e.VendorName).HasMaxLength(100);
                entity.Property(e => e.VendorPhone).HasMaxLength(100);
            });




        }
    } 
}