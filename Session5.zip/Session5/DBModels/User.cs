﻿namespace Session5.DBModels
{
    public class User
    {
        public decimal Id { get; set; }

        public string? FullName { get; set; }

        public string EmailId { get; set; } = null!;

        public string? Password { get; set; }

        public string? Designation { get; set; }

        public DateTime? CreatedDate { get; set; }
    }
}
