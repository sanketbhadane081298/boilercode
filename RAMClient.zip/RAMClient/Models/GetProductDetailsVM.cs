﻿using RAM.Model.Product;

namespace RAMClient.Models
{
    public class GetProductDetailsVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        public string Description { get; set; }
        public List<GetCategoryDto> Categories { get; set; }
    }
}
