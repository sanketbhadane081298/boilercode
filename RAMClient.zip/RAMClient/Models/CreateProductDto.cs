﻿namespace RAMClient.Models
{
    public class CreateProductDto
    {
        public string Name { get; set; }
        public int Price { get; set; }
        public string Description { get; set; }
    }
}
