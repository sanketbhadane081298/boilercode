﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RAMClient.Models;
using System.Text;

namespace RAMClient.Controllers
{
    public class ProductController : Controller
    {
        public async Task<ActionResult> GetAllProducts()
        {
            
            List<GetProductsVM> allProducts = new List<GetProductsVM>();
            using (var httpclient = new HttpClient())
            {
                using (var response = await httpclient.GetAsync("https://localhost:7120/api/Product"))
                {
                    string data = response.Content.ReadAsStringAsync().Result;
                    allProducts = JsonConvert.DeserializeObject<List<GetProductsVM>>(data);
                }
                return View(allProducts);
            }

        }
        [HttpGet]
        public async Task<ActionResult> GetProuctById(int id)
        {
            GetProductDetailsVM Prouct = new GetProductDetailsVM();
            using (var httpclient = new HttpClient())
            {
                using (var response = await httpclient.GetAsync("https://localhost:7120/api/Product/" + id))
                {
                    string data = response.Content.ReadAsStringAsync().Result;
                    Prouct = JsonConvert.DeserializeObject<GetProductDetailsVM>(data);
                }
                return View(Prouct);
            }

        }
        [HttpGet]
        public async Task<ActionResult> CreateProduct()
        {
            return View();
        }
        [HttpPost]
        public async Task<ActionResult> CreateProduct(CreateProductDto createProductDto)
        {
            CreateProductDto product = new CreateProductDto();
            using (var httpclient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(createProductDto), Encoding.UTF8, "application/json");
                using (var response = await httpclient.PostAsync("https://localhost:7120/api/Product", content))
                {
                    string data = response.Content.ReadAsStringAsync().Result;
                    product = JsonConvert.DeserializeObject<CreateProductDto>(data);
                }
                ModelState.Clear();
                return View();
                
            }

        }
        [HttpGet]
        [Route("UpdateP")]
        public async Task<ActionResult> UpdateP(int id)
        {
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:7120/api/Product/" + id))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        string data = response.Content.ReadAsStringAsync().Result;
                        UpdateProductDto product = JsonConvert.DeserializeObject<UpdateProductDto>(data);
                        return View(product);
                    }
                    else
                    {
                        // Handle error case
                        return View("Error");
                    }
                }
            }
        }

        [HttpPost]
        [Route("UpdateP")]
        public async Task<ActionResult> UpdateP(UpdateProductDto updateProductDto)
        {
            using (var httpClient = new HttpClient())
            {
                var jsonContent = new StringContent(JsonConvert.SerializeObject(updateProductDto), Encoding.UTF8, "application/json");
                using (var response = await httpClient.PutAsync("https://localhost:7120/api/Product/" + updateProductDto.Id, jsonContent))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        // Product updated successfully
                        return RedirectToAction("GetAllProducts");
                    }
                    else
                    {
                        // Handle error case
                        ModelState.AddModelError("", "Failed to update product.");
                        return View(updateProductDto);
                    }
                } 
            }
        }

        [HttpPost]
        [Route("DeletePr")]
        public async Task<ActionResult> DeletePr(int id)
        {
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.DeleteAsync("https://localhost:7120/api/Product/" + id))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        // Product deleted successfully
                        return RedirectToAction("GetAllProducts");
                    }
                    else
                    {
                        // Handle error case
                        return View("Error");
                    }
                }
            }
        }

    }
}
